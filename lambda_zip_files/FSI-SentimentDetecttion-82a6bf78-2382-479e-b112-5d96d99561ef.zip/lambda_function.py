import json
import boto3
import logging
from http import HTTPStatus


logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
  
    client = boto3.client('comprehend')
    textInput = json.dumps(event, indent=2)
    try:
        # Call Comprehend to get sentiment of text input
        response = client.detect_sentiment(
            Text= textInput,
            LanguageCode='en'
        )
    
    except Exception as e:  # Catch all for easier error tracing in logs
        logger.error(e, exc_info=True)
        raise Exception('Error occurred during execution')  # notify failure
    return {
        "statusCode": HTTPStatus.OK.value,
        "body": response,
        "headers": {
            "Content-Type": "application/json"
        }
    }