import json
import boto3
import os
import logging
from http import HTTPStatus

AUDIOTRANSCRIPTS_SOURCE_BUCKET= os.getenv("AUDIOTRANSCRIPTS_SOURCE_BUCKET")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def datachunk(para):
    text_list = []
    # Deconstruct data into  chunks
    while para:
        text_list.append(str(para[:4700]))
        para = para[4700:]
    return text_list[:25]
    
    
def lambda_handler(event, context):
    
    comprehend = boto3.client("comprehend")
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    keyphases = ['']
    try:
        # List objects in the bucket
        response = s3_client.list_objects_v2(Bucket=AUDIOTRANSCRIPTS_SOURCE_BUCKET)

        # Iterate through each object in the bucket
        for obj in response['Contents']:
            # Get the object key
            object_key = obj['Key']

            # Retrieve the object
            object_response = s3_client.get_object(Bucket=AUDIOTRANSCRIPTS_SOURCE_BUCKET, Key=object_key)

            # Get the contents of the object
            object_body = object_response['Body'].read().decode("utf-8")
            response = comprehend.batch_detect_key_phrases(TextList = datachunk(object_body), LanguageCode = "en")
            for i in response["ResultList"]:
                for j in i["KeyPhrases"] :
    
                    keyphases.append(j["Text"])
    except Exception as e:  # Catch all for easier error tracing in logs
            logger.error(e, exc_info=True)
            raise Exception('Error occurred during execution')  # notify failure
    return {
        'statusCode': HTTPStatus.OK.value,
        'body': keyphases
    }
