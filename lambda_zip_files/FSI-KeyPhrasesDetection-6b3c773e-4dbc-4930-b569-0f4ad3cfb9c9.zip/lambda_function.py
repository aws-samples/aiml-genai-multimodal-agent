import json
import boto3
import os
import logging
from http import HTTPStatus

AUDIOTRANSCRIPTS_SOURCE_BUCKET= os.getenv("AUDIOTRANSCRIPTS_SOURCE_BUCKET")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def datachunk(para):
    text_list = []
    # Deconstruct data into  chunks
    while para:
        text_list.append(str(para[:4700]))
        para = para[4700:]
    return text_list[:25]
    
    
def lambda_handler(event, context):
    print(event)
    try:
        comprehend = boto3.client("comprehend")
        response = comprehend.detect_key_phrases(
        Text=event,
        LanguageCode='en'
        )
        keyphases=[x['Text'] for x in response['KeyPhrases']]
    except Exception as e:  # Catch all for easier error tracing in logs
            logger.error(e, exc_info=True)
            raise Exception('Error occurred during execution')  # notify failure
    return {
        'statusCode': HTTPStatus.OK.value,
        'body': keyphases
    }
